using EmployeeWebAPI.DAL;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//configure DataAccessLayer for dependency injection
builder.Services.Add(new ServiceDescriptor(typeof(IDatabase), typeof(EFDataAccessLayer), ServiceLifetime.Transient));

//configure DbContext for using SQL Server details
builder.Services.AddDbContext<EmpDBContext>(options =>
{
    options.UseSqlServer("Data Source=.\\sqlexpress;Initial Catalog=JCIEMPDB;Integrated Security=True;Encrypt=False");
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
