﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EmployeeWebAPI.Models
{
    //[Table("tbl_employee", Schema = "dbo")]
    public class tbl_employee
    {
        [Key]
        public int ecode { get; set; }
        public string ename { get; set; }
        public int salary { get; set; }
        public int deptid { get; set; }
    }
}
