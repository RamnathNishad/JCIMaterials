﻿using EmployeeWebAPI.Models;

namespace EmployeeWebAPI.DAL
{
    public interface IDatabase
    {
        List<tbl_employee> GetAllEmps();
    }
}
