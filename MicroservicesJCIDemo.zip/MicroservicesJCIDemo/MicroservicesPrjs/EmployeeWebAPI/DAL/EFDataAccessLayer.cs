﻿using EmployeeWebAPI.Models;

namespace EmployeeWebAPI.DAL
{
    public class EFDataAccessLayer : IDatabase
    {
        private readonly EmpDBContext dbCtx;
        public EFDataAccessLayer(EmpDBContext dbCtx)
        {
            this.dbCtx = dbCtx;
        }
        public List<tbl_employee> GetAllEmps( )
        {
            var lstEmps = dbCtx.tbl_employee.ToList();
            return lstEmps;
        }
    }
}
