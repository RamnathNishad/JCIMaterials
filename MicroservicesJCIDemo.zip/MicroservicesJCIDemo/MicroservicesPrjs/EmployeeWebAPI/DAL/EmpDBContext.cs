﻿using EmployeeWebAPI.Models;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace EmployeeWebAPI.DAL
{
    public class EmpDBContext : DbContext
    {
        public EmpDBContext(DbContextOptions<EmpDBContext> options) 
            : base(options)
        {

        }

       
        public DbSet<tbl_employee> tbl_employee { get; set; }
    }
}
