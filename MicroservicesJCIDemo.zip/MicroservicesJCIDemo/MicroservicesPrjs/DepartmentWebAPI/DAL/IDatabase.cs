﻿using DepartmentWebAPI.Models;

namespace DepartmentWebAPI.DAL
{
    public interface IDatabase
    {
        List<tbl_department> GetAllDepts();
    }
}
