﻿using DepartmentWebAPI.Models;

namespace DepartmentWebAPI.DAL
{
    public class EFDataAccessLayer : IDatabase
    {
        private readonly DeptDbContext dal;
        public EFDataAccessLayer(DeptDbContext dal)
        {
            this.dal = dal;
        }

        public List<tbl_department> GetAllDepts()
        {
            return dal.tbl_Departments.ToList();
        }
    }
}
