﻿using DepartmentWebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace DepartmentWebAPI.DAL
{
    public class DeptDbContext : DbContext
    {
        public DeptDbContext(DbContextOptions<DeptDbContext> options)
            : base(options)
        {

        }

        public DbSet<tbl_department> tbl_Departments { get; set; }
    }
}
