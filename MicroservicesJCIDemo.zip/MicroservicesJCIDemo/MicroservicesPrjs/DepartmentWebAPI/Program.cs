using DepartmentWebAPI.DAL;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//configure dependency injection for the DataAccessLayer object
builder.Services.Add(new ServiceDescriptor(typeof(IDatabase),typeof(EFDataAccessLayer),ServiceLifetime.Transient));

//configure DbContext for the Sql Server details
builder.Services.AddDbContext<DeptDbContext>(options =>
{
    options.UseSqlServer("Data Source=.\\sqlexpress;Initial Catalog=JCIDEPTDB;Integrated Security=True;Encrypt=False");
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
