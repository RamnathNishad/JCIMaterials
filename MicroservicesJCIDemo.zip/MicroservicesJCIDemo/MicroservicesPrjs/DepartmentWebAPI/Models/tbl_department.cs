﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DepartmentWebAPI.Models
{
    [Table("tbl_department",Schema ="dbo")]
    public class tbl_department
    {
        [Key]
        public int Deptid { get; set; }
        public string Dname { get; set; }
        public int Dhead { get; set; }
    }
}
